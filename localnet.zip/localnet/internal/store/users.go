package store

import (
	"errors"
	"log"
	"sync"
)

type UserStore struct {
	users map[string]string
	mu    sync.Mutex
}

func NewUserStore() *UserStore {
	return &UserStore{
		users: make(map[string]string),
	}
}

func (s *UserStore) Register(username, password string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, exists := s.users[username]; exists {
		return errors.New("user already exists")
	}
	s.users[username] = password
	return nil
}

func (s *UserStore) Authenticate(username, password string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	pass, ok := s.users[username]
	if !ok {
		log.Printf("Authenticate failed: user %s not found", username)
		return false
	}
	if pass != password {
		log.Printf("Authenticate failed: incorrect password for user %s", username)
		return false
	}
	log.Printf("Authenticate success for user %s", username)
	return true
}
