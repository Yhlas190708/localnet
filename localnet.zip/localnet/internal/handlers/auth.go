package handlers

import (
	"html/template"
	"localnet/internal/store"
	"log"
	"net/http"
)

type AuthHandler struct {
	users     *store.UserStore
	Templates *template.Template
}

func NewAuthHandler(users *store.UserStore) *AuthHandler {
	templates := template.Must(template.ParseGlob("templates/*.html"))
	return &AuthHandler{users: users, Templates: templates}
}

func (h *AuthHandler) RegisterForm(w http.ResponseWriter, r *http.Request) {
	err := h.Templates.ExecuteTemplate(w, "register.html", nil)
	if err != nil {
		return
	}
}

func (h *AuthHandler) Register(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Redirect(w, r, "/register", http.StatusSeeOther)
		return
	}
	username := r.FormValue("username")
	password := r.FormValue("password")

	err := h.users.Register(username, password)
	if err != nil {
		log.Printf("Register failed: %v", err)
		err := h.Templates.ExecuteTemplate(w, "register.html", "User already exists")
		if err != nil {
			return
		}
		return
	}
	log.Printf("User registered: %s", username)
	http.Redirect(w, r, "/login", http.StatusSeeOther)
}

func (h *AuthHandler) LoginForm(w http.ResponseWriter, r *http.Request) {
	err := h.Templates.ExecuteTemplate(w, "login.html", nil)
	if err != nil {
		return
	}
}

func (h *AuthHandler) Login(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}
	username := r.FormValue("username")
	password := r.FormValue("password")

	log.Printf("Attempt login user=%s password=%s", username, password)

	if h.users.Authenticate(username, password) {
		http.SetCookie(w, &http.Cookie{
			Name:  "user",
			Value: username,
			Path:  "/",
		})
		http.Redirect(w, r, "/chat", http.StatusSeeOther)
	} else {
		err := h.Templates.ExecuteTemplate(w, "login.html", "Invalid credentials")
		if err != nil {
			return
		}
	}
}

func (h *AuthHandler) Logout(w http.ResponseWriter, r *http.Request) {
	cookie := &http.Cookie{
		Name:   "user",
		Value:  "",
		Path:   "/",
		MaxAge: -1,
	}
	http.SetCookie(w, cookie)
	http.Redirect(w, r, "/login", http.StatusSeeOther)
}

// Новый метод для показа страницы чата с передачей имени пользователя в шаблон
func (h *AuthHandler) Chat(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("user")
	if err != nil || cookie.Value == "" {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	data := map[string]string{
		"Username": cookie.Value,
	}

	err = h.Templates.ExecuteTemplate(w, "chat.html", data)
	if err != nil {
		http.Error(w, "Ошибка загрузки страницы", http.StatusInternalServerError)
	}
}
