package handlers

import (
	"fmt"
	"net/http"
	"os"
	"path/filepath"
)

func (h *AuthHandler) UploadFileHandler(w http.ResponseWriter, r *http.Request) {
	// Проверяем, что пользователь авторизован
	cookie, err := r.Cookie("user")
	if err != nil || cookie.Value == "" {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	// Если GET - показываем форму
	if r.Method == http.MethodGet {
		h.Templates.ExecuteTemplate(w, "upload.html", nil)
		return
	}

	// Если POST - обрабатываем загрузку файла
	if r.Method == http.MethodPost {
		file, header, err := r.FormFile("uploadfile")
		if err != nil {
			http.Error(w, "Ошибка загрузки файла", http.StatusBadRequest)
			return
		}
		defer file.Close()

		// Создаем файл в папке static/uploads
		dstPath := filepath.Join("static/uploads", header.Filename)
		dst, err := os.Create(dstPath)
		if err != nil {
			http.Error(w, "Ошибка сохранения файла", http.StatusInternalServerError)
			return
		}
		defer dst.Close()

		// Копируем содержимое загруженного файла
		_, err = dst.ReadFrom(file)
		if err != nil {
			http.Error(w, "Ошибка записи файла", http.StatusInternalServerError)
			return
		}

		fmt.Fprintf(w, "Файл %s успешно загружен!", header.Filename)
		return
	}

	http.Error(w, "Метод не поддерживается", http.StatusMethodNotAllowed)
}
