package ws

import (
	"encoding/json"
	"log"
	"sync"
)

// Hub
type Hub struct {
	mu         sync.Mutex
	Clients    map[*Client]bool
	Users      map[string]*Client // map username -> client
	Register   chan *Client
	Unregister chan *Client
	Broadcast  chan []byte
	broadcast  chan []byte
}

// В NewHub добавляем инициализацию Users
func NewHub() *Hub {
	return &Hub{
		Clients:    make(map[*Client]bool),
		Users:      make(map[string]*Client),
		Register:   make(chan *Client),
		Unregister: make(chan *Client),
		Broadcast:  make(chan []byte),
	}
}
func (h *Hub) FindClientByUsername(username string) *Client {
	for client := range h.Clients {
		if client.Username == username {
			return client
		}
	}
	return nil
}

// Run меняем — обрабатываем регистрацию и удаление пользователей
func (h *Hub) Run() {
	for {
		select {
		case client := <-h.Register:
			h.mu.Lock()
			h.Clients[client] = true
			h.Users[client.Username] = client
			h.mu.Unlock()

		case client := <-h.Unregister:
			h.mu.Lock()
			if _, ok := h.Clients[client]; ok {
				delete(h.Clients, client)
				delete(h.Users, client.Username)
				close(client.Send)
			}
			h.mu.Unlock()

		case message := <-h.Broadcast:
			// Для сигнальных сообщений: если они в JSON, ищем поле "to" и отправляем конкретно
			var msg map[string]interface{}
			if err := json.Unmarshal(message, &msg); err == nil {
				if to, ok := msg["to"].(string); ok && to != "" {
					h.mu.Lock()
					if c, exists := h.Users[to]; exists {
						select {
						case c.Send <- message:
						default:
							close(c.Send)
							delete(h.Clients, c)
							delete(h.Users, c.Username)
						}
					}
					h.mu.Unlock()
					continue // не рассылаем всем
				}
			}
			// Если обычное сообщение — рассылаем всем
			h.mu.Lock()
			for client := range h.Clients {
				select {
				case client.Send <- message:
				default:
					close(client.Send)
					delete(h.Clients, client)
					delete(h.Users, client.Username)
				}
			}
			h.mu.Unlock()
		}
	}
}
func (h *Hub) BroadcastMessage(msg interface{}) {
	data, err := json.Marshal(msg)
	if err != nil {
		log.Println("BroadcastMessage marshal error:", err)
		return
	}
	h.broadcast <- data
}

func (h *Hub) RegisterClient(client *Client) {
	h.Register <- client
}
