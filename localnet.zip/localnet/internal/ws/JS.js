const socket = new WebSocket("ws://localhost:8080/ws");

socket.onmessage = function(event) {
    const msg = JSON.parse(event.data);
    const chat = document.getElementById("chat");
    const el = document.createElement("div");
    el.textContent = msg.username + ": " + msg.message;
    chat.appendChild(el);
};

function sendMessage() {
    const input = document.getElementById("msgInput");
    socket.send(input.value);
    input.value = "";
}
