package ws

import (
	"encoding/json"
	"fmt"
	"github.com/gorilla/websocket"
	"log"
	"os"
	"path/filepath"
	"time"
)

type Client struct {
	Hub      *Hub
	Conn     *websocket.Conn
	Send     chan []byte
	Username string
}

// Структура signaling сообщения для WebRTC
type SignalMessage struct {
	Type    string          `json:"type"`    // "offer", "answer", "candidate"
	Payload json.RawMessage `json:"payload"` // данные SDP или ICE
	To      string          `json:"to"`      // имя пользователя получателя
	From    string          `json:"from"`    // имя отправителя
}

func (c *Client) ReadPump() {
	defer func() {
		c.Hub.Unregister <- c
		c.Conn.Close()
	}()

	for {
		messageType, data, err := c.Conn.ReadMessage()
		if err != nil {
			log.Println("read error:", err)
			break
		}

		// Попытка распарсить signaling сообщение для звонка
		var sigMsg SignalMessage
		if err := json.Unmarshal(data, &sigMsg); err == nil && sigMsg.Type != "" {
			// Это signaling-сообщение — пересылаем нужному клиенту
			peerClient := c.Hub.FindClientByUsername(sigMsg.To)
			if peerClient != nil {
				peerClient.Send <- data
			}
			continue
		}

		// Если бинарное сообщение — сохраняем файл
		if messageType == websocket.BinaryMessage {
			uploadDir := "static/uploads"
			if err := os.MkdirAll(uploadDir, 0755); err != nil {
				log.Println("failed to create upload dir:", err)
				continue
			}

			filename := fmt.Sprintf("file_%d.dat", time.Now().UnixNano())
			filepath := filepath.Join(uploadDir, filename)
			err = os.WriteFile(filepath, data, 0644)
			if err != nil {
				log.Println("file save error:", err)
				continue
			}

			link := fmt.Sprintf(`<a href="/static/uploads/%s" download>%s</a>`, filename, filename)
			msg := fmt.Sprintf(`{"username":"%s","content":%q}`, c.Username, link)
			c.Hub.Broadcast <- []byte(msg)

		} else if messageType == websocket.TextMessage {
			// Обычное текстовое сообщение — рассылаем всем
			msg := fmt.Sprintf(`{"username":"%s","content":%q}`, c.Username, string(data))
			c.Hub.Broadcast <- []byte(msg)
		}
	}
}

func (c *Client) WritePump() {
	defer c.Conn.Close()

	for msg := range c.Send {
		err := c.Conn.WriteMessage(websocket.TextMessage, msg)
		if err != nil {
			break
		}
	}
}
