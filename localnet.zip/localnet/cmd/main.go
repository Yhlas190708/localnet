package main

import (
	"io"
	"log"
	"net/http"
	"text/template"

	"localnet/internal/handlers"
	"localnet/internal/store"
	"localnet/internal/ws"
)

func main() {
	userStore := store.NewUserStore()
	authHandler := handlers.NewAuthHandler(userStore)

	hub := ws.NewHub()
	go hub.Run()

	wsHandler := handlers.NewWSHandler(hub)

	// Главная страница с кнопкой регистрации
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		tmpl := template.Must(template.ParseFiles("templates/index.html"))
		tmpl.Execute(w, nil)
	})

	// Статические файлы
	http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))

	http.HandleFunc("/register", authHandler.RegisterForm)
	http.HandleFunc("/register/submit", authHandler.Register)

	http.HandleFunc("/login", authHandler.LoginForm)
	http.HandleFunc("/login/submit", authHandler.Login)

	http.HandleFunc("/upload", authHandler.UploadFileHandler)

	http.HandleFunc("/logout", authHandler.Logout)

	http.HandleFunc("/chat", func(w http.ResponseWriter, r *http.Request) {
		cookie, err := r.Cookie("user")
		if err != nil || cookie.Value == "" {
			http.Redirect(w, r, "/login", http.StatusSeeOther)
			return
		}
		authHandler.Templates.ExecuteTemplate(w, "chat.html", struct {
			Username string
		}{
			Username: cookie.Value,
		})
	})

	http.HandleFunc("/chat/send", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
			return
		}
		cookie, err := r.Cookie("user")
		if err != nil || cookie.Value == "" {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}

		err = r.ParseForm()
		if err != nil {
			http.Error(w, "Bad Request", http.StatusBadRequest)
			return
		}

		msg := r.FormValue("message")
		if msg == "" {
			http.Error(w, "Message is empty", http.StatusBadRequest)
			return
		}

		type ChatMessage struct {
			Username string `json:"username"`
			Content  string `json:"content"`
		}
		message := ChatMessage{
			Username: cookie.Value,
			Content:  msg,
		}

		hub.BroadcastMessage(message)

		http.Redirect(w, r, "/chat", http.StatusSeeOther)
	})

	http.HandleFunc("/ws", wsHandler.ServeWS)
	http.HandleFunc("/ping", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("pong"))
	})

	http.HandleFunc("/upload-test", func(w http.ResponseWriter, r *http.Request) {
		io.Copy(io.Discard, r.Body)
		w.WriteHeader(http.StatusOK)
	})

	log.Println("Server started on http://localhost:8080/")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
